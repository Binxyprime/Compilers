#ifndef _LISTTOKEN
#include <string>

class listToken{
	public:
		std::string type;
		std::string name;
};

#endif