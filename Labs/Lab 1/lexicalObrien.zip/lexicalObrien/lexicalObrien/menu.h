//menu.h
//Justin OBrien

#include <iostream>
#include <fstream>
#include <string>
#include "lexical.h"
#include <vector>

void RunMenu();
