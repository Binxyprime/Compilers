#include <string>

class symbol{
public:
	std::string name;
	std::string type;
	std::string use;
	std::string value;
private:
};